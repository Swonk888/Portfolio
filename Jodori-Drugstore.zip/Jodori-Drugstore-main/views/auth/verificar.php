<h1>Verifica Tu Cuenta</h1>
<?php 
    include_once __DIR__ . "/../templates/alerts.php";
?>
<div class="actions">
    <a class="blue-btn" href="/login">Inicia Sesión</a>
    <a class="orange-btn" href="/register">Crear Cuenta</a>
</div>
