import './map.js';
import './register-form.js';
import './reports.js';
import './update-activity.js';
import './comment.js';
import './coordinator.js';