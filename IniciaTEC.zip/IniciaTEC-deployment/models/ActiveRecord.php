<?php
namespace Model;
class ActiveRecord {

    protected static $db;
    protected static $table = '';
    protected static $columnsDB = [];

    protected static $alerts = [];
    
    public static function setDB($database) {
        self::$db = $database;
    }

    public static function setalert($type, $message) {
        static::$alerts[$type][] = $message;
    }

    public static function getAlerts() {
        return static::$alerts;
    }

    public function validate() {
        static::$alerts = [];
        return static::$alerts;
    }

    public static function querySQL($query) {
        $result = self::$db->query($query);
    
        $array = [];
        while($register = $result->fetch_assoc()) {
            $array[] = static::createObject($register);
        }
        $result->free();
        return $array;
    }

    protected static function createObject($register) {
        $object = new static;

        foreach($register as $key => $value ) {
            if(property_exists( $object, $key  )) {
                $object->$key = $value;
            }
        }
        return $object;
    }

    public function attributes() {
        $attributes = [];
        foreach(static::$columnsDB as $column) {
            if($column === 'id') continue;
            $attributes[$column] = $this->$column;
        }
        return $attributes;
    }

    public function sanitizeAttributes() {
        $attributes = $this->attributes();
        $sanitized = [];
        foreach($attributes as $key => $value ) {
            if(!is_null($value)) {
                $sanitized[$key] = self::$db->escape_string($value);
            }
        }
        return $sanitized;
    }

    public function sync($args=[]) { 
        foreach($args as $key => $value) {
          if(property_exists($this, $key) && !is_null($value)) {
            $this->$key = $value;
          }
        }
    }

    public function save() {
        $result = '';
        if(!is_null($this->id)) {
            $result = $this->update();
        } else {
            $result = $this->create();
        }
        return $result;
    }

    public static function all($order = 'DESC') {
        $query = "SELECT * FROM " . static::$table . " ORDER BY id $order";
        $result = self::querySQL($query);
        return $result;
    }

    public static function find($id) {
        $query = "SELECT * FROM " . static::$table  ." WHERE id = $id";
        $result = self::querySQL($query);
        return array_shift( $result ) ;
    }
    public static function find2($nombre) {
        $query = "SELECT id FROM " . static::$table  ." WHERE nombre = '$nombre'";
        $result = self::$db->query($query);
        return ( $result ) ;
    }
    public static function find3($equipoId) {
        $query = "SELECT profesorId FROM " . static::$table  ." WHERE equipoId = '$equipoId'";
        $result = self::$db->query($query);
        return ( $result ) ;
    }
    

    public static function get($limit) {
        $query = "SELECT * FROM " . static::$table . " ORDER BY id DESC LIMIT $limit" ;
        $result = self::querySQL($query);
        return $result;
    }

    public static function where($column, $value) {
        $query = "SELECT * FROM " . static::$table . " WHERE $column = '$value'";
        $result = self::querySQL($query);
        return array_shift( $result ) ;
    }

    public static function whereAll($column, $value) {
        $query = "SELECT * FROM " . static::$table . " WHERE $column = '$value'";
        $result = self::querySQL($query);
        return $result;
    }

    public static function whereOrder($column, $value, $order) {
        $query = "SELECT * FROM " . static::$table . " WHERE $column = '$value' ORDER BY $order";
        $result = self::querySQL($query);
        return $result;
    }

    public static function whereNull($column1, $value, $column2) {
        $query = "SELECT * FROM " . static::$table . " WHERE $column2 IS NULL AND $column1 = '$value'";
        $result = self::querySQL($query);
        return $result;
    }

    public static function whereNotNull($column1, $value, $column2) {
        $query = "SELECT * FROM " . static::$table . " WHERE $column2 IS NOT NULL AND $column1 = '$value'";
        $result = self::querySQL($query);
        return $result;
    }

    public static function order($column, $order){
        $query = "SELECT * FROM " . static::$table . " ORDER BY $column $order";
        $result = self::querySQL($query);
        return $result;
    }

    public static function orderLimit($column, $order, $limit){
        $query = "SELECT * FROM " . static::$table . " ORDER BY $column $order LIMIT $limit";
        $result = self::querySQL($query);
        return $result;
    }

    public static function whereArray($array = []) {
        $query = "SELECT * FROM " . static::$table . " WHERE ";
        foreach($array as $key => $value) {
            if($key  == array_key_last($array)){
                $query .= "$key = '$value' ";
            } else{
                $query .= "$key = '$value' AND ";
            }
        }
        // $query = substr($query, 0, -4);
        $result = self::querySQL($query);
        return $result;
    }

    public function create() {
        $attributes = $this->sanitizeAttributes();
        $query = "INSERT INTO " . static::$table . " ( ";
        $query .= join(', ', array_keys($attributes));
        $query .= " ) VALUES ('"; 
        $query .= join("', '", array_values($attributes));
        $query .= "') ";
        $result = self::$db->query($query);
        return [
           'result' =>  $result,
           'id' => self::$db->insert_id
        ];
    }

    public function update() {
        $attributes = $this->sanitizeAttributes();
        $values = [];
        foreach($attributes as $key => $value) {
            $values[] = "{$key}='{$value}'";
        }

        $query = "UPDATE " . static::$table ." SET ";
        $query .=  join(', ', $values );
        $query .= " WHERE id = '" . self::$db->escape_string($this->id) . "' ";
        $query .= " LIMIT 1 "; 

        // debug($query);

        $result = self::$db->query($query);
        return $result;
    }

    public function delete() {
        $query = "DELETE FROM "  . static::$table . " WHERE id = " . self::$db->escape_string($this->id) . " LIMIT 1";
        $result = self::$db->query($query);
        return $result;
    }

    public static function count($column = '', $value = '') {
        $query = "SELECT COUNT(*) FROM " . static::$table;
        if($column && $value){
            $query .= " WHERE $column = '$value'";
        }
        $result = self::$db->query($query);
        $count = $result->fetch_array();
        return array_shift($count);
    }
    public static function join($Query)
    {
        $query = $Query;
        $result = self::$db->query($query);
        return $result;
    }

    public static function totalArray($array = []) {
        $query = "SELECT COUNT(*) FROM " . static::$table . " WHERE ";
        foreach($array as $key => $value) {
            if($key  == array_key_last($array)){
                $query .= "$key = '$value' ";
            } else{
                $query .= "$key = '$value' AND ";
            }
        }
        $result = self::$db->query($query);
        $count = $result->fetch_array();
        return array_shift($count);
    }
    public static function update2($query) {
        $result = self::$db->query($query);
    }

    public static function paginate($per_page, $offset){
        $query = "SELECT * FROM " . static::$table . " ORDER BY id DESC LIMIT $per_page OFFSET $offset" ;
        $result = self::querySQL($query);
        return $result;
    }

    public static function whereTwo($column1, $value1, $column2, $value2) {
        $query = "SELECT * FROM " . static::$table . " WHERE $column1 = '$value1' AND $column2 = '$value2'";
        $result = self::querySQL($query);
        return $result ;
    }

    public static function whereThree($column1, $value1, $column2, $value2, $column3, $value3) {
        $query = "SELECT * FROM " . static::$table . " WHERE $column1 = '$value1' AND $column2 = '$value2' AND $column3 = '$value3'";
        $result = self::querySQL($query);
        return $result ;
    }
}