<main class="page_404">
    <h1 class="page_404__heading">404</h1>
    <p class="page_404__message">La página que buscas no pudo ser encontrada</p>
    <a href="/" class="page_404__home">Volver a Inicio</a>
</main>