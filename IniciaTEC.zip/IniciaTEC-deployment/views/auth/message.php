<div class="auth--centered">
    <h1 class="auth__title">Cambio de Contraseña Solicitado</h1>
    <p class="auth__description">Hemos enviado las instrucciones para cambiar tu contraseña a tu correo</p>

        <div class="form__actions">
            <a href="/login" class="form__submit">Volver al Inicio de Sesión</a>
        </div>
    </form>
</div>