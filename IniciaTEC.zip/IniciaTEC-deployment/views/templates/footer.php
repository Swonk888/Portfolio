<footer class="footer">
    <p class="footer__copy">
        IniciaTEC
        <span class="footer__copy--regular">
            - Todos los derechos reservados <?php echo date('Y') ?> &copy;
        </span>
    </p>
</footer>